import Foundation
import CreateML
import PlaygroundSupport

if let path = Bundle.main.url(forResource: "finalJsonData", withExtension: "json") {
    do {
        var table = try MLDataTable(contentsOf: path)
        table.removeColumn(named: "date1")
        table.removeColumn(named: "date2")
        table.removeColumn(named: "date3")
        print(table.dropMissing().playgroundDescription)
        let split = table.dropMissing().randomSplit(by: 1)
        var classifier = try MLClassifier(trainingData: split.0, targetColumn: "result")
        classifier.evaluation(on: split.1)
        let p = playgroundSharedDataDirectory.appendingPathComponent("blizzard1.mlmodel")
        try classifier.write(to: p, metadata: MLModelMetadata(author: "Addison Hanrattie", shortDescription: "This is the first version of my model that only takes in data from one snow season and only light data", license: "This model may not be shared used or recreated at all", version: "1.0", additional: nil))
    } catch {
        print(error)
    }
}


/*NOTES:

Boosted tree seemed to be the models favored choice
I only use 10 iterations for selecting the model allowing more may increase accuracy
25% evaluates at around 89
 50% of data use evaluated at around 93% accuracy
80% evaluates at 90.91 but only tests on 1 class
75% evaluates at 94 and tests on two classes
>90% always evaluates to 100
*/
